function [xy]=find_xy(x_n,y_n,data)

N = size(data,1); % number of samples
val = max(max(data))+1; % maximum number of values of features
xy = zeros(val,val);

if (x_n==1||x_n==5||x_n==6||x_n==7)
    val_1 = 4;
end
if (x_n==2||x_n==4||x_n==8)
    val_1 = 5;
end
if (x_n==3||x_n==9)
    val_1 = 3;
end

if (y_n==1||y_n==5||y_n==6||y_n==7)
    val_2 = 4;
end
if (y_n==2||y_n==4||y_n==8)
    val_2 = 5;
end
if (y_n==3||y_n==9)
    val_2 = 3;
end

for x = 1:val_1
    for y = 1:val_2
        for n = 1:N
            if (data(n,x_n) == x-1)&&(data(n,y_n) == y-1)
                xy(x,y) = xy(x,y)+1;
            end
        end
    end
end
textdata = cellfun(@str2num,textdata_c(:,1));
text = cellstr(num2str(textdata,'%04d'));
textdata_c=[text textdata_c(:,2)];
img_c = strcat(textdata_c(:,1),textdata_c(:,2));
img_cn = img_c;
img_cx =  cellfun(@str2num,textdata_c(:,1));

% textdata = cellfun(@str2num,textdata_h(:,1));
% text = cellstr(num2str(textdata,'%04d'));
% textdata_h=[text textdata_h(:,2)];
img_h = strcat(textdata_h(:,1),textdata_h(:,2));
img_hn = img_h;

% for i = 1:size(data_c,1)
%     for k = 1:samples_c
%         if data_c(i,:) == x_out_c(k,:)
%             fig_c(k,:)= textdata_c(i,:);
%         end
%     end
% end
% for i = 1:size(data_h,1)
%     for k = 1:samples_h
%         if data_h(i,:) == x_out_h(k,:)
%             fig_h(k,:)= textdata_h(i,:);
%         end
%     end
% end

N_c = size(data_c,1);
p_joint_c = zeros(N_c,2);

N_h = size(data_h,1);
p_joint_h = zeros(N_h,2);

for i = 1:N_c
    p_joint_c(i,1)= joint_prob_indep(data_c(i,:),px_c);
    p_joint_c(i,2)= joint_prob_cursive(data_c(i,:),px_c, pxa_xb_c);
    count_c(i,1) = i;
end

for i = 1:N_h
    p_joint_h(i,1)= joint_prob_indep(data_h(i,:),px_h);
    p_joint_h(i,2) = joint_prob_handprint(data_h(i,:),px_h,pxa_xb_h);
    count_h(i,1) = i;
end

b = cellfun(@num2str,{data_c(:,1:9)},'UniformOutput',false);
c = cellfun(@(x) strrep(x,' ',''), cellstr(b{1}),'UniformOutput',false);
c = str2double(c);
p_joint_c = [count_c c p_joint_c];
p_joint_c = sortrows(p_joint_c,-3);
 
j = 0;
p_joint_ci = zeros(size(unique(c),1),4);
count_ci = zeros(size(unique(c),1),1);
old = 000000000;
for i = 1:N_c
    new = p_joint_c(i,2);
    if new ~= old
        j = j+1;
        count_ci(j,1) = j;
        p_joint_ci(j,:) = p_joint_c(i,:);
        old = new;
    end
end

p_joint_ci = [p_joint_ci(:,1) count_ci p_joint_ci(:,2:4)];

b = cellfun(@num2str,{data_h(:,1:9)},'UniformOutput',false);
c = cellfun(@(x) strrep(x,' ',''), cellstr(b{1}),'UniformOutput',false);
c = str2double(c);
p_joint_h = [count_h c p_joint_h];
p_joint_h = sortrows(p_joint_h,-3);

j = 0;
p_joint_hi = zeros(size(unique(c),1),4);
count_hi = zeros(size(unique(c),1),1);
old = 000000000;
for i = 1:N_h
    new = p_joint_h(i,2);
    if new ~= old
        j = j+1;
        count_hi(j,1) = j;
        p_joint_hi(j,:) = p_joint_h(i,:);
        old = new;
    end
end

p_joint_hi = [p_joint_hi(:,1) count_hi p_joint_hi(:,2:4)];

p_joint_c = [p_joint_c(:,1) count_c p_joint_c(:,2:4)];
p_joint_h = [p_joint_h(:,1) count_h p_joint_h(:,2:4)];

for i = 1:N_c
    img_cn(i,1) = img_c(p_joint_c(i,1),1);
end

for i = 1:N_h
    img_hn(i,1) = img_h(p_joint_h(i,1),1);
end

columnLabels = {'\\#','Img', 'ID','Samples', 'Joint Prob', 'Indep Prob'};
matrix2latex(img_cn, p_joint_ci, 'out_c.tex', 'columnLabels', columnLabels, 'alignment', 'c', 'format', '%10.2e\n');

matrix2latex(img_hn, p_joint_hi, 'out_h.tex', 'columnLabels', columnLabels, 'alignment', 'c', 'format', '%10.2e\n');
% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: train_bn_cursive.m
% Description: Trains the parameters of Bayesian Network structure for
% cursive dataset.

function [px2_x1x6] = extra_prob_cursive(data)

%values for additive smoothing
a = 1;

N = size(data,1); % number of samples
val = max(max(data))+1; % maximum number of values of features
n_feat = size(data,2); % number of features

m = 0; %value to initialize count

%initialization of variables - conditional probabilities of factors
px2_x1x6 = zeros(val,val,val);

%initialization of variables - count of joint occurances
x1x6ml = m*ones(val,val);
x2x1x6ml = m*ones(val,val,val);

%counting the required joint occurances needed to calculate conditional
%probabilities feom data
for n = 1:N
    for j = 1:val
        for k = 1:val
            %ML(X1,X6)
            if (data(n,1) == j-1)&&(data(n,6) == k-1)
                x1x6ml(j,k) = x1x6ml(j,k)+1;
            end
            for l = 1:val
                %ML(X2,X1,X6)
                if (data(n,2) == j-1)&&(data(n,1) == k-1)&&(data(n,6) == l-1)
                    x2x1x6ml(j,k,l) = x2x1x6ml(j,k,l)+1;
                end
            end
        end
    end
end

%calculation of conditional probabilities of factors in given BN graph
for i = 1:val
    for j = 1:val
        for k = 1:val
            px2_x1x6(i,j,k) = (x2x1x6ml(i,j,k)+a)/(x1x6ml(j,k)+(max(data(:,2))+1)*a);
        end
    end
end
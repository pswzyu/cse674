function [dag,count_out]=check_parent(str, x_a, x_b, count_in)
dag = 1;
count = count_in;
for i = 1:9
    if str(x_b,i) == 1
        if i == x_a
            dag = 0;
        else
            for j = 1:9
                if str(i,j) == 1
                    if j == x_a
                        dag = 0;
                    else
                        for k = 1:9
                            if str(j,k) == 1
                                if k == x_a
                                    dag = 0;
                                else
                                    for l = 1:9
                                        if str(k,l) == 1
                                            if l == x_a
                                                dag = 0;
                                            else
                                                for m = 1:9
                                                    if str(l,m) == 1
                                                        if m == x_a
                                                            dag = 0;
                                                        else
                                                            for n = 1:9
                                                                if str(m,n) == 1
                                                                    if n == x_a
                                                                        dag = 0;
                                                                    else
                                                                        for o = 1:9
                                                                            if str(n,o) == 1
                                                                                if o == x_a
                                                                                    dag = 0;
                                                                                else
                                                                                    for p = 1:9
                                                                                        if str(o,p) == 1
                                                                                            if p == x_a
                                                                                                dag = 0;
                                                                                            else
                                                                                                for q = 1:9
                                                                                                    if str(p,q) == 1
                                                                                                        if q == x_a
                                                                                                            dag = 0;
                                                                                                        else
                                                                                                        end
                                                                                                    end
                                                                                                end
                                                                                            end
                                                                                        end
                                                                                    end
                                                                                end
                                                                            end
                                                                        end
                                                                    end
                                                                end
                                                            end
                                                        end
                                                    end
                                                end
                                            end
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
                
%             if (count < 25)
%                 count = count+1;
%                 dag = check_parent(str, x_a, i, count);  
%             end
        end        
    end
end

count_out = count;
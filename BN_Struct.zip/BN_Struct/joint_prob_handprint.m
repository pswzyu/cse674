function [prob]=joint_prob_handprint(data,px,pxa_xb)
n = 1;
prob = (px(7,data(n,7)+1))*(px(2,data(n,2)+1))*(px(3,data(n,3)+1))*(px(9,data(n,9)+1))*(px(6,data(n,6)+1))*(pxa_xb(8,6,data(n,8)+1,data(n,6)+1))*(pxa_xb(1,6,data(n,1)+1,data(n,6)+1))*(pxa_xb(5,1,data(n,5)+1,data(n,1)+1))*(pxa_xb(4,5,data(n,4)+1,data(n,5)+1));
%clear all
clc
load ('data_c.mat');
load ('data_h.mat');
load ('textdata_c.mat');
textdata = cellfun(@str2num,textdata_c(:,1));
text = cellstr(num2str(textdata,'%04d'));
textdata_c=[text textdata_c(:,2)];
img_c = strcat(textdata_c(:,1),textdata_c(:,2));
img_cn = img_c;

load ('textdata_h.mat');
textdata = cellfun(@str2num,textdata_h(:,1));
text = cellstr(num2str(textdata,'%04d'));
textdata_h=[text textdata_h(:,2)];
img_h = strcat(textdata_h(:,1),textdata_h(:,2));
img_hn = img_h;

for n = 1:size(data_h,1)
    for p = 1:size(data_h,2)
        if data_h(n,p) == -1
            data_h(n,p) = 1;
        end
    end
end

for n = 1:size(data_c,1)
    for p = 1:size(data_c,2)
        if data_c(n,p) == -1
            data_c(n,p) = 1;
        end
    end
end


[px_c,pxa_xb_c,pxa_xbxc_c]=find_prob(data_c);

[struct_c, new_lik_c, nindep_lik_c] = learn_bn_structure(px_c, pxa_xb_c, pxa_xbxc_c, data_c, 1);

%px2_x1x6_c = extra_prob_cursive(data_c);

%[log_loss_bn_c,log_loss_indep_c,prc_c,nprc_c,cond_nprc_c] = infer_cursive(data_c,px_c,pxa_xb_c,pxa_xbxc_c);

%Generating 10 samples using Gibbs sampling
%[x_out_c, px_out_c] = gibbs_sampling_bnc(px_c,pxa_xb_c,samples_c,data_c);



[px_h,pxa_xb_h,pxa_xbxc_h]=find_prob(data_h);

[struct_h, new_lik_h,nindep_lik_h] = learn_bn_structure(px_h, pxa_xb_h, pxa_xbxc_h, data_h, 0);

%px1_x6x8_h = extra_prob_handprint(data_h);

%[log_loss_bn_h,log_loss_indep_h,prc_h,nprc_h,cond_nprc_h] = infer_handprint(data_h,px_h,pxa_xb_h,pxa_xbxc_h);

%Generating 10 samples using Gibbs sampling
%samples_h = 10;
%[x_out_h, px_out_h] = gibbs_sampling_bnc(px_h,pxa_xb_h,samples_h,data_h);


% x = 3:152;
% figure(1)
% plot(x, nprc_c,'-', x, nprc_h, '-.');
% xlabel('n')
% ylabel('nPRC BN hand-print')
% title('nPRC vs number of samples(n) hand-print')
% legend('BN Cursive', 'BN Handprint')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% new_pair = zeros(9,9);
% new_pair(4,5) = 1;
% old_str = zeros(9,9);
% 
% [new_lik,new_str]=new_struct(data,new_pair,log_lik_indep,px,pxa_xb,old_str);
% 
% old_lik = new_lik;
% 
% new_pair = zeros(9,9);
% new_pair(4,9) = 1;
% 
% old_str = new_str;
% 
% new_str = old_str;
% new_str(a,b) = 1;
% [new_lik,new_str]=new_struct(data,new_pair,old_lik,px,pxa_xb,old_str);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
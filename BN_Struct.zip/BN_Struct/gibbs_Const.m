prob = (px(9,val(9)))*(px(2,val(2)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(6,2,val(6),val(2)))*(pxa_xb(1,7,val(1),val(7)))*(pxa_xb(7,4,val(7),val(4)))*(pxa_xb(4,2,val(4),val(2)))*(pxa_xb(5,3,val(5),val(3)))*(pxa_xb(3,4,val(3),val(4)));



prob = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
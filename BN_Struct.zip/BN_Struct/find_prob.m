function [px,pxa_xb,pxa_xbxc] = find_prob(data)

N = size(data,1); % number of samples
val = max(max(data))+1; % maximum number of values of features
n_feat = size(data,2); % number of features

%values for additive smoothing
a = 1;

%initialization of variables - conditional probabilities of factors
px = zeros(n_feat,val);
pxa_xb = zeros(n_feat,n_feat, val, val);
pxa_xbxc = zeros(n_feat,n_feat,n_feat,val,val,val);

m = 0; %value to initialize count

%initialization of variables - count of joint occurances
xml = m*ones(n_feat,val);
xaxbml = zeros(n_feat,n_feat,val,val);
xaxbxcml = zeros(n_feat,n_feat,n_feat,val,val,val);

%counting the required joint occurances needed to calculate conditional
%probabilities from data
for n = 1:N
    for j = 1:val
        for i = 1:n_feat
            if data(n,i) == j-1
                xml(i,j) = xml(i,j) +1;
            end
        end
    end
end

for x_a = 1:9
    for x_b = 1:9
        xaxbml(x_a,x_b,:,:)=find_xy(x_a,x_b,data);
        for x_c = 1:9
            for n = 1:N
                for j = 1:val
                    for k = 1:val
                        for l = 1:val
                            %ML(Xa,Xb,Xc)
                            if (data(n,x_a) == j-1)&&(data(n,x_b) == k-1)&&(data(n,x_c) == l-1)
                                xaxbxcml(x_a,x_b,x_c,j,k,l) = xaxbxcml(x_a,x_b,x_c,j,k,l)+1;
                            end
                        end
                    end
                end
            end
        end
    end
end

%calculation of marginal probabilities of all nodes in graph
for l = 1:9
    px(l,:) = (xml(l,:)+a)/(N+(max(data(:,l))+1)*a);
end

%calculation of conditional probabilities of factors in given BN graph
for x_a = 1:9
    for x_b = 1:9 
        for i = 1:val
            for j = 1:val
                pxa_xb(x_a,x_b,i, j) = (xaxbml(x_a,x_b,i,j)+a)/(xml(x_b,j)+(max(data(:,x_a))+1)*a);
            end
        end
    end
end

for x_a = 1:9
    for x_b = 1:9 
        for x_c = 1:9
            for i = 1:val
                for j = 1:val
                    for k = 1:val
                        pxa_xbxc(x_a,x_b,x_c,i,j,k) = (xaxbxcml(x_a,x_b,x_c,i,j,k)+a)/(xaxbml(x_b,x_c,j,k)+(max(data(:,x_a))+1)*a);
                    end
                end
            end
        end
    end
end
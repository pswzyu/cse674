function [all_chi]=find_all_chi(px,data,cur)

all_chi = zeros(9,9);
for x_n = 1:9
    for y_n = 1:9
        all_chi(x_n,y_n)=chi_sq(px,x_n,y_n,data,cur);
    end
end

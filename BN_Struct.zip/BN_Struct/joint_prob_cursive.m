function [prob]=joint_prob_cursive(data,px,pxa_xb)
n = 1;
prob = (px(9,data(n,9)+1))*(px(2,data(n,2)+1))*(pxa_xb(8,6,data(n,8)+1,data(n,6)+1))*(pxa_xb(6,2,data(n,6)+1,data(n,2)+1))*(pxa_xb(1,7,data(n,1)+1,data(n,7)+1))*(pxa_xb(7,4,data(n,7)+1,data(n,4)+1))*(pxa_xb(4,2,data(n,4)+1,data(n,2)+1))*(pxa_xb(5,3,data(n,5)+1,data(n,3)+1))*(pxa_xb(3,4,data(n,3)+1,data(n,4)+1));


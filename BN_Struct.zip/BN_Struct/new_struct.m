function [new_lik,new_str]=new_struct(data,new_pair,old_lik,px,pxa_xb,old_str)
N = size(data,1); % number of samples
n_feat = size(data,2); % number of features

[a,b] = find(new_pair==1);

a_pair = 1;
b_pair = 1;

for i = 1:n_feat
    if (old_str(i,b)==1) 
        b_pair = 0;
    end
    if (old_str(a,i)==1) 
        a_pair = 0;
    end
end

new_lik = old_lik;

for n = 1:N
    new_lik = new_lik - a_pair*log(px(a,data(n,a)+1)) - b_pair*log(px(b,data(n,b)+1)) + log(pxa_xb(a,b,data(n,a)+1,data(n,b)+1));
end

new_str = old_str;

if (new_lik > old_lik)
    new_str(a,b) = 1;
end
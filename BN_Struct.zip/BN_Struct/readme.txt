This file contains the instructions needed to run the MATLAB code used for BN structure learning in the
paper 'Bayesian Network Structure Learning and Inference Methods for Handwriting'

INSTRUCTION TO RUN CODE: 
- Open main_BN.m in matlab  and run.

NOTE: 
- The folder also contains some *.m files that are not required for the structure learning process. These
  files are mainly used to calculate values for the inference tasks. I would suggest starting at main_BN.m
  and then looking at the *.m files for any functions used.
- The files primarily used in structure learning are as follows:
  --learn_bn_structure.m : Main function to learn the BN structure
  --find_prob.m : finds all required conditional probabilities. Please note that the algorithm limits the
                  number of parents to 2 so, we need to find conditional probabilities for each node given 
                  2 parent nodes.
  --files for all other supported functions are also included. Commented versions will be uploaded later.

RESULTS: 
- After running the code, results will be stored in struct_c (structure for cursive) and 
  struct_h (structure for handprint).
- Results obtained from my experiments are stored as struct_c.mat and struct_h.mat. These can also be 
  opened in MATLAB.
- The columns indicate the parents of the rows. For eg. in struct_c, in the 1st column, 2nd row, X1 is a
  parent of X2.
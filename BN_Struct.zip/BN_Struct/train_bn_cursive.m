% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: train_bn_cursive.m
% Description: Trains the parameters of Bayesian Network structure for
% cursive dataset.

function [px,px2_x1,px4_x3x5,px7_x6x8,px9_x2x4x7] = train_bn_cursive(data)

%values for additive smoothing
a = 1;
d = 5;

N = size(data,1); % number of samples
val = max(max(data))+1; % maximum number of values of features
n_feat = size(data,2); % number of features

m = 0; %value to initialize count

%initialization of variables - conditional probabilities of factors
px = zeros(n_feat,val);
px2_x1 = zeros(val,val);
px4_x3x5 = zeros(val,val,val);
px7_x6x8 = zeros(val,val,val);
px9_x2x4x7 = zeros(val,val,val,val);

%initialization of variables - count of joint occurances
xml = m*ones(n_feat,val);
x2x1ml = m*ones(val,val);
x4x3x5ml = m*ones(val,val,val);
x7x6x8ml = m*ones(val,val,val);
x9x2x4x7ml = m*ones(val,val,val,val);
x3x5ml = m*ones(val,val);
x6x8ml = m*ones(val,val);
x2x4x7ml = m*ones(val,val,val);

%counting the required joint occurances needed to calculate conditional
%probabilities feom data
for n = 1:N
    for j = 1:val
        for i = 1:n_feat
            if data(n,i) == j-1
                xml(i,j) = xml(i,j) +1;
            end
        end
        
        for k = 1:val
            %ML(X2,X1)
            if (data(n,2) == k-1)&&(data(n,1) == j-1)
                x2x1ml(k, j) = x2x1ml(k,j)+1;
            end
            
            %ML(X3,X5)
            if (data(n,3) == k-1)&&(data(n,5) == j-1)
                x3x5ml(k,j) = x3x5ml(k,j)+1;
            end
            
            %ML(X6,X8)
            if (data(n,6) == k-1)&&(data(n,8) == j-1)
                x6x8ml(k,j) = x6x8ml(k,j)+1;
            end
            
            for l = 1:val
                %ML(X4,X3,X5)
                if (data(n,5) == j-1)&&(data(n,3) == k-1)&&(data(n,4) == l-1)
                    x4x3x5ml(l,k,j) = x4x3x5ml(l,k,j)+1;
                end
                
                %ML(X7,X6,X8)
                if (data(n,8) == j-1)&&(data(n,6) == k-1)&&(data(n,7) == l-1)
                    x7x6x8ml(l,k,j) = x7x6x8ml(l,k,j)+1;
                end
                
                %ML(X2,X4,X7)
                if (data(n,7) == j-1)&&(data(n,4) == k-1)&&(data(n,2) == l-1)
                    x2x4x7ml(l,k,j) = x2x4x7ml(l,k,j)+1;
                end
                
                for m = 1:val
                    %ML(X9,X2,X4,X7)
                    if (data(n,7) == j-1)&&(data(n,4) == k-1)&&(data(n,2) == l-1)&&(data(n,9) == m-1)
                        x9x2x4x7ml(m,l,k,j) = x9x2x4x7ml(m,l,k,j)+1;
                    end
                end
            end
        end
    end
end

%calculation of marginal probabilities of all nodes in graph
for l = 1:9
    px(l,:) = (xml(l,:)+a)/(N+(max(data(:,l))+1)*a);
end

%calculation of conditional probabilities of factors in given BN graph
for i = 1:val
    for j = 1:val
        px2_x1(i, j) = (x2x1ml(i,j)+a)/(xml(1,j)+(max(data(:,2))+1)*a);
        for k = 1:val
            px4_x3x5(i,j,k) = (x4x3x5ml(i,j,k)+a)/(x3x5ml(j,k)+(max(data(:,4))+1)*a);
            px7_x6x8(i,j,k) = (x7x6x8ml(i,j,k)+a)/(x6x8ml(j,k)+(max(data(:,7))+1)*a);
            for l = 1:val
                px9_x2x4x7(i,j,k,l) = (x9x2x4x7ml(i,j,k,l)+a)/(x2x4x7ml(j,k,l)+(max(data(:,9))+1)*a);
            end
        end
    end
end
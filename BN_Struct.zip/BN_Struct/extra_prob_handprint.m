% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: train_bn_cursive.m
% Description: Trains the parameters of Bayesian Network structure for
% cursive dataset.

function [px1_x6x8] = extra_prob_handprint(data)

%values for additive smoothing
a = 1;

N = size(data,1); % number of samples
val = max(max(data))+1; % maximum number of values of features
n_feat = size(data,2); % number of features

m = 0; %value to initialize count

%initialization of variables - conditional probabilities of factors
px1_x6x8 = zeros(val,val,val);

%initialization of variables - count of joint occurances
x6x8ml = m*ones(val,val);
x1x6x8ml = m*ones(val,val,val);

%counting the required joint occurances needed to calculate conditional
%probabilities feom data
for n = 1:N
    for j = 1:val
        for k = 1:val
            %ML(X6,X8)
            if (data(n,6) == j-1)&&(data(n,8) == k-1)
                x6x8ml(j,k) = x6x8ml(j,k)+1;
            end
            for l = 1:val
                %ML(X1,X6,X8)
                if (data(n,1) == j-1)&&(data(n,6) == k-1)&&(data(n,8) == l-1)
                    x1x6x8ml(j,k,l) = x1x6x8ml(j,k,l)+1;
                end
            end
        end
    end
end

%calculation of conditional probabilities of factors in given BN graph
for i = 1:val
    for j = 1:val
        for k = 1:val
            px1_x6x8(i,j,k) = (x1x6x8ml(i,j,k)+a)/(x6x8ml(j,k)+(max(data(:,1))+1)*a);
        end
    end
end
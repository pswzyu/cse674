function [dag]=check_dag(str,x_a,x_b)
count = 0;
[dag,count_out] = check_parent(str,x_a,x_b,count);
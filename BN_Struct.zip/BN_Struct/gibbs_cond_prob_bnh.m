% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: gibbs_cond_prob_bnc.m
% Description: Determines the values of the conditional probabilities
% required in Gibbs sampling for BN of hand-print 'and'.
function [pc] = gibbs_cond_prob_bnh(px,px5_x3,px2_x3x5,px4_x2x3,px6_x2x5,px8_x5x6,px7_x3x4x6,px1_x5x6x8,i,val)

%Determining number of conditional probability values possible for each
%variable Xi
if (i == 2)||(i == 7)
    val_n = 6;
end
if (i == 1)||(i == 3)||(i == 4)||(i == 6)
    val_n = 5;
end
if (i == 8)
    val_n = 4;
end
if (i == 5)||(i == 9)
    val_n = 3;
end

val = val+1;

pc = zeros(1,val_n);
pj = zeros(1,val_n);

%Calculating value of joint probabilities for all values of Xi using BN
%model for hand-print dataset
for xi = 1:val_n
    if i == 1
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(i,6,xi,val(6)))*(pxa_xb(5,i,val(5),xi))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 2
        pj(xi) = (px(7,val(7)))*(px(i,xi))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 3
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(i,xi))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 4
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(i,5,xi,val(5)));
    end
    if i == 5
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(i,1,xi,val(1)))*(pxa_xb(4,i,val(4),xi));
    end
    if i == 6
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(i,xi))*(pxa_xb(8,i,val(8),xi))*(pxa_xb(1,i,val(1),xi))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 7
        pj(xi) = (px(i,xi))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 8
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(9,val(9)))*(px(6,val(6)))*(pxa_xb(i,6,xi,val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
    if i == 9
        pj(xi) = (px(7,val(7)))*(px(2,val(2)))*(px(3,val(3)))*(px(i,xi))*(px(6,val(6)))*(pxa_xb(8,6,val(8),val(6)))*(pxa_xb(1,6,val(1),val(6)))*(pxa_xb(5,1,val(5),val(1)))*(pxa_xb(4,5,val(4),val(5)));
    end
end

%Calculating the conditional probability from the joint probability
%obtained using BN model
for j = 1:val_n
    pc(j) = pj(j)/sum(pj);
end
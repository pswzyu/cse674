function [new_str,new_lik,indep_lik] = learn_bn_structure(px, pxa_xb, pxa_xbxc, data, cur)

all_chi = find_all_chi(px,data, cur);

indep_lik = log_lik_indep(data,px);

new_lik = indep_lik;
new_str = zeros(9,9);
repeat = 1;

while repeat
    [a,b] = find(all_chi == max(max(all_chi)));

    x_a = a(1);
    x_b = b(1);
    
    if (x_a == x_b)
        all_chi(x_a,x_b) = 0;
    else
        old_str = new_str;
        old_lik = new_lik;

        if(all_chi(x_a,x_b) ~= 0)
            all_chi(x_a,x_b) = 0;
            
            new_pair = zeros(9,9);
            new_pair(x_a,x_b) = 1;
            [new_lik] = new_likely(data,new_pair,old_lik,px,pxa_xb,pxa_xbxc,old_str);
            
            str = old_str;
            str(x_a,x_b) = 1;
            dag = check_dag(str,x_a,x_b);
            
            if (dag == 1)&&(new_lik > old_lik)
                new_str = old_str;
                new_str(x_a,x_b) = 1;
            else
                new_str = old_str;
                new_lik = old_lik;
            end
            
        end
        
        old_lik_r = new_lik;

        if(all_chi(x_b,x_a) ~= 0)
            all_chi(x_b,x_a) = 0;
            
            new_pair = zeros(9,9);
            new_pair(x_b,x_a) = 1;
            [new_lik_r] = new_likely(data,new_pair,old_lik,px,pxa_xb,pxa_xbxc,old_str);
            
            str = old_str;
            str(x_b,x_a) = 1;
            dag = check_dag(str,x_b,x_a);
 
            if (dag == 1)&&(new_lik > old_lik_r)
                new_str = old_str;
                new_str(x_b,x_a) = 1;
                new_lik = new_lik_r;
            end
        end

        if (all_chi == 0)
            repeat = 0;
        end        
    end
end

function [log_lik]=log_lik_indep(data,px)
log_lik = 0;
for n = 1:size(data,1)
    %Calculation of log likelihood value assuming all variables independent 
    log_lik = log_lik+log(px(1,data(n,1)+1))+log(px(2,data(n,2)+1))+log(px(3,data(n,3)+1))+log(px(4,data(n,4)+1))+log(px(5,data(n,5)+1))+log(px(6,data(n,6)+1))+log(px(7,data(n,7)+1))+log(px(8,data(n,8)+1))+log(px(9,data(n,9)+1));
end

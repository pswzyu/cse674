function [new_lik]=new_likely(data,new_pair,old_lik,px,pxa_xb,pxa_xbxc,old_str)
N = size(data,1); % number of samples
n_feat = size(data,2); % number of features

[a,b] = find(new_pair==1);

a_parent = 0;
a_parent2 = 0;
p = 1;

for i = 1:n_feat
    if (old_str(a,i)==1) 
        if(a_parent == 0)
            a_parent = 1; %a has another parent
            p = i;
        else
            a_parent2 = 1;
        end
    end
end

new_lik = old_lik;

for n = 1:N
    if(a_parent2 == 0)
        new_lik = new_lik - (~a_parent)*log(px(a,data(n,a)+1)) + (~a_parent)*log(pxa_xb(a,b,data(n,a)+1,data(n,b)+1)) - (a_parent)* log(pxa_xb(a,p,data(n,a)+1,data(n,p)+1))+ (a_parent)* log(pxa_xbxc(a,p,b,data(n,a)+1,data(n,p)+1,data(n,b)+1));
    end
end


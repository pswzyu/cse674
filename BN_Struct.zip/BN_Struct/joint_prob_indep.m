function [pxj]=joint_prob_indep(xs,px)
pxj = px(1,xs(1)+1)*px(2,xs(2)+1)*px(3,xs(3)+1)*px(4,xs(4)+1)*px(5,xs(5)+1)*px(6,xs(6)+1)*px(7,xs(7)+1)*px(8,xs(8)+1)*px(9,xs(9)+1);

% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: gibbs_sampling_bnc.m
% Description: Produces 10 samples of cursive 'and' using gibbs sampling. 
function [x_out, px_out] = gibbs_sampling_bnc(px,pxa_xb,samples,data)

burnin = 1000; %burn-in iterations to discard effect of initialized value
x_out = zeros(samples,9);
px_out = zeros(samples,1);
x = [0,1,2,3,0,1,2,3,0]; %initial sample to start sampling

i = 1;
while i <=(burnin+samples)
    for node = 1:9
        %calculation of required conditional probability
        [pc] = gibbs_cond_prob_bnc(px,pxa_xb,node,x);
        
        %sampling new value of x from conditional probability
        ran = rand(1);
        low = 0;
        for k = 1:size(pc,2)
            if (ran>low)&&(ran<pc(1,k)+low)
                x(1,node) = k-1;
            end
            low = pc(1,k)+low;
        end
    end
    
    %start recording samples after burn-in iterations have completed
    if (i > burnin)
        found = 0;
        
        %to negate the effect of smoothing, only select values within the
        %dataset
        for j = 1:size(data,1)
            if data(j,:) == x(1,:)
                x_out(i-burnin,:) = x;
                found = 1;
            end
        end
        if (found == 0)
            i = i-1;
        end
    end
    i = i+1;
end
for i = 1:samples
    px_out(i,1) = joint_prob_cursive(x_out(i,:),px,pxa_xb);
end
% Name: Mukta Puri
% Class: CSE 574
% Project2
% Filename: infer_bn_cursive.m
% Description: For cursive data, performs inference tasks based on the 
% Bayesian Network model. Also, performs evaluation of the model.
function [log_loss_bn,log_loss_indep,prc,nprc,cond_nprc] = infer_cursive(data, px,pxa_xb,px2_x1x6)

log_likelihood_bn = 0;
prc = 0;
nprc = zeros(1,150);
cond_nprc = zeros(1,2);

%Calculation of log likelihood value assuming all variables independent 
log_likelihood_indep = log_lik_indep(data,px);

for n = 1:size(data,1)
    %Calculation of log likelihood value for given BN graph
    %log_likelihood_bn = log_likelihood_bn+log(px2_x1x6(data(n,2)+1,data(n,1)+1,data(n,6)+1))+log(px(7,data(n,7)+1))+log(pxa_xb(9,5,data(n,9)+1,data(n,5)+1))+log(pxa_xb(5,3,data(n,5)+1,data(n,3)+1))+log(pxa_xb(3,4,data(n,3)+1,data(n,4)+1))+log(pxa_xb(4,2,data(n,4)+1,data(n,2)+1))+log(pxa_xb(1,8,data(n,1)+1,data(n,8)+1))+log(pxa_xb(6,8,data(n,6)+1,data(n,8)+1))+log(pxa_xb(7,8,data(n,7)+1,data(n,8)+1));
    log_likelihood_bn = log_likelihood_bn+log(px(9,data(n,9)+1))+log(px(2,data(n,2)+1))+log(pxa_xb(8,6,data(n,8)+1,data(n,6)+1))+log(pxa_xb(6,2,data(n,6)+1,data(n,2)+1))+log(pxa_xb(1,7,data(n,1)+1,data(n,7)+1))+log(pxa_xb(7,4,data(n,7)+1,data(n,4)+1))+log(pxa_xb(4,2,data(n,4)+1,data(n,2)+1))+log(pxa_xb(5,3,data(n,5)+1,data(n,3)+1))+log(pxa_xb(3,4,data(n,3)+1,data(n,4)+1));
end

%Determination of log loss from log likelihood
log_loss_bn = log_likelihood_bn*(-1);
log_loss_indep = log_likelihood_indep*(-1);

%Calculation of the PRC for given BN model
for x1 = 0:3
    for x2 = 0:4
        for x3 = 0:2
            for x4 = 0:4
                for x5 = 0:3
                    for x6 = 0:3
                        for x7 = 0:3
                            for x8 = 0:4
                                for x9 = 0:2
                                    x = [x1,x2,x3,x4,x5,x6,x7,x8,x9];
                                    prc = prc + (joint_prob_cursive(x,px,pxa_xb)^2);
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end

%Calculating nPRC for different values of n and plotting the graph
for n_nprc = 3:152
    nprc(1,n_nprc-2) = 1-(1-prc)^(n_nprc*(n_nprc-1)/2);
end

%Calculating conditional nPRC for different samples for n = 7000
n_nprc = 7000;

xs = [1,1,1,0,1,2,0,0,2]; %sample to calculate conditional nPRC
pxs = joint_prob_cursive(xs,px,pxa_xb);
cond_nprc(1,1) = 1-((1-pxs)^(n_nprc-1));

%Calculating conditional nPRC for different samples
xs = [0,1,0,2,2,3,0,3,2]; %sample to calculate conditional nPRC
pxs = joint_prob_cursive(xs,px,pxa_xb);
cond_nprc(1,2) = 1-((1-pxs)^(n_nprc-1));


